const app = require('../backend/server');

module.exports = app;
